def sum_of_primes(n: int) -> int:
    """Checks prime status or generates prime numbers using sieve."""
    if n < 2:
        return 0
    is_prime = [True] * (n + 1)
    is_prime[0] = is_prime[1] = False
    for p in range(2, int(n**0.5) + 1):
        if is_prime[p]:
            for i in range(p * p, n + 1, p):
                is_prime[i] = False
    return sum(i for i in range(2, n + 1) if is_prime[i])

if __name__ == '__main__':
    n = int(input())
    print(sum_of_primes(n))