from typing import List

class Solution:
    def rearrange(self, nums: List[int]) -> List[int]:
        pos = [x for x in nums if x >= 0]
        neg = [x for x in nums if x < 0]
        return pos + neg