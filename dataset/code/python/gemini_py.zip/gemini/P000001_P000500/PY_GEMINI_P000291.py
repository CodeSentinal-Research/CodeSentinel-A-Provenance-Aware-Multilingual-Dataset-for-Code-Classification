class Solution:
    def checkInclusion(self, s1: str, s2: str) -> bool:
        n1, n2 = len(s1), len(s2)
        if n1 > n2:
            return False

        c1 = [0] * 26
        c2 = [0] * 26
        for c in s1:
            c1[ord(c) - ord('a')] += 1

        for i in range(n2):
            c2[ord(s2[i]) - ord('a')] += 1
            if i >= n1:
                c2[ord(s2[i - n1]) - ord('a')] -= 1
            if c1 == c2:
                return True

        return False