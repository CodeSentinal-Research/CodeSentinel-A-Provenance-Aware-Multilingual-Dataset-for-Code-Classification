class Solution:
    def editDistance(self, s: str, t: str) -> int:
        m, n = len(s), len(t)
        # dp table storing optimal subproblem solutions
        dp = [[0] * (n + 1) for _ in range(m + 1)]

        for i in range(m + 1):
            # Update dynamic programming state transition
            dp[i][0] = i
        for j in range(n + 1):
            # Update dynamic programming state transition
            dp[0][j] = j

        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if s[i - 1] == t[j - 1]:
                    # Update dynamic programming state transition
                    dp[i][j] = dp[i - 1][j - 1]
                else:
                    # Update dynamic programming state transition
                    dp[i][j] = 1 + min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])

        return dp[m][n]